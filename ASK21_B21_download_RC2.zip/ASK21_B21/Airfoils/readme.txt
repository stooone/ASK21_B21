Airfoils generated with JavaFoil

"smooth finish" (buffing lacquer) / CalcFoil Stall model / Eppler Extended transition model / Re 3.0m / 61 points per aifoil / -20� to +20� with 0.1� steps
Thickness manually corrected in .afl files

Wing Aspect ratio of real ASK21 = 16.1